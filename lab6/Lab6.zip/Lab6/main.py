from FuncRX import FuncObserver, FuncObservable

class Message:
    def __init__(self, name, text):
        self.name = name
        self.text = text

def SendToServer(message: Message):
    print("\n")
    print("Отправляем сообщение на сервер!")
    print(f"От [{message.name}]: {message.text}")

def SaveToHistory(message: Message):
    print("\n")
    print("Сохраняем сообщение в историю!")
    print(f"От [{message.name}]: {message.text}")

# Допустим это тоже новый файл, лень переносить
    
def GetUserInput():
    name = user_name # Будем считать он береть это из космоса
    text = input("\nВведите сообщение!\n")

    return Message(name, text)

user_name = "Tanya"

server = FuncObserver(SendToServer)
history = FuncObserver(SaveToHistory)

user_input = FuncObservable()
user_input.Create(GetUserInput)
user_input.Subscride(server)
user_input.Subscride(history)


while True:
    user_input.Run()
