from MySuperRX import IObservable, IObserver

class FuncObserver(IObserver):
    def __init__(self, Handler):
        self.Handler = Handler

    def Update(self, *args, **kwargs):
        if self.Handler:
            self.Handler(*args, **kwargs)

class FuncObservable(IObservable):
    def __init__(self):
        self.subscribers: IObserver = []

    def Subscride(self, observer: IObserver):
        self.subscribers.append(observer)

    def Unsubscride(self, observer: IObserver):
        self.subscribers.remove(observer)

    def Notify(self, *args, **kwargs):
        for observer in self.subscribers:
            observer.Update(*args, **kwargs)

    def Create(self, Func):
        self.Func = Func

    def Run(self, *args, **kwargs):
        data = self.Func(*args, **kwargs)
        self.Notify(data)