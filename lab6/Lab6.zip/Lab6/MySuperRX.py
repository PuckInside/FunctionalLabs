from abc import ABC, abstractmethod

class IObserver(ABC):
    @abstractmethod
    def Update(self):
        pass

class IObservable(ABC):
    @abstractmethod
    def Subscride(self, observer: IObserver):
        pass
    
    @abstractmethod
    def Unsubscride(self, observer: IObserver):
        pass

    @abstractmethod
    def Notify(self):
        pass


